// SurakshaVaani server: keeps the hazard log and makes every Gemini call.
// The Gemini key stays here, on the server, and never reaches the browser.
import express from "express";
import { GoogleGenAI } from "@google/genai";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const KEY = process.env.GEMINI_API_KEY || process.env.API_KEY || "";
const MODEL = process.env.GEMINI_MODEL || "gemini-3.6-flash";
// GEMINI_BASE_URL is only for testing against a stand-in server; leave it unset.
const ai = KEY ? new GoogleGenAI({ apiKey: KEY, ...(process.env.GEMINI_BASE_URL ? { httpOptions: { baseUrl: process.env.GEMINI_BASE_URL } } : {}) }) : null;

/* ---------- Reference data (same as the page) ---------- */
const H = 3600e3;
const STARTED = Date.now();
const ZONES = ["Tower A", "Tower B", "Basement & excavation", "Scaffolding yard", "Batching plant", "Labour camp", "Site roads & gate"];
const CATS = [
  { id: "fall", label: "Fall from height", sev: "high" },
  { id: "electrical", label: "Electrical", sev: "high" },
  { id: "collapse", label: "Excavation or collapse", sev: "high" },
  { id: "lifting", label: "Crane and lifting", sev: "high" },
  { id: "struck", label: "Struck by vehicle or object", sev: "medium" },
  { id: "fire", label: "Fire", sev: "high" },
  { id: "ppe", label: "Missing PPE", sev: "medium" },
  { id: "heat", label: "Heat and welfare", sev: "medium" },
  { id: "housekeeping", label: "Housekeeping and trips", sev: "low" },
  { id: "other", label: "Other", sev: "medium" }
];
const CAT = Object.fromEntries(CATS.map(c => [c.id, c]));
const SEVRANK = { high: 3, medium: 2, low: 1 };
const catLabel = id => (CAT[id] || CAT.other).label;

/* ---------- Store: one JSON file. Swap these functions for Firestore to make it permanent. ---------- */
const DATA_DIR = path.join(ROOT, "data");
const DATA_FILE = path.join(DATA_DIR, "tickets.json");
const tickets = new Map();   // id -> ticket
let rev = 1;                 // bumps on every change, so pages only re-download when something changed
let saveTimer = null;

function loadStore() {
  let list = null;
  try { list = JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); } catch {}
  if (!Array.isArray(list)) list = JSON.parse(fs.readFileSync(path.join(ROOT, "seed-tickets.json"), "utf8"));
  for (const t of list) tickets.set(t.id, t);
}
function saveSoon() {
  rev++;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(DATA_FILE, JSON.stringify([...tickets.values()])); }
    catch (e) { console.error("Couldn't save the log:", e.message); }
  }, 300);
}
const tCreated = t => t.seeded ? STARTED - (t.seedAgeHours || 0) * H : (t.createdAt || STARTED);
function nextCode() {
  let max = 100;
  for (const t of tickets.values()) { const n = parseInt(String(t.code || "").replace(/\D/g, ""), 10); if (n > max) max = n; }
  return "SV-" + (max + 1);
}
const newId = () => "t" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

/* ---------- Gemini helpers ---------- */
function dataUrlPart(u) {
  const m = /^data:([^;,]+);base64,(.+)$/.exec(String(u || ""));
  return m ? { inlineData: { mimeType: m[1], data: m[2] } } : null;
}
async function gemJSON(prompt, parts = []) {
  const res = await ai.models.generateContent({
    model: MODEL,
    contents: [{ role: "user", parts: [{ text: prompt }, ...parts] }],
    config: { responseMimeType: "application/json", temperature: 0.2 }
  });
  const txt = res.text || "";
  try { return JSON.parse(txt); }
  catch { const m = txt.match(/\{[\s\S]*\}/); if (m) return JSON.parse(m[0]); throw new Error("Gemini did not return JSON"); }
}

/* ---------- Triage ---------- */
function rulesTriage(text) {
  const s = String(text || "").toLowerCase();
  const has = (...w) => w.some(x => s.includes(x));
  let category = "other";
  if (has("railing","रेलिंग","edge","किनार","गिर","height","ऊँचाई","ऊंचाई","harness","हार्नेस","net","जाली","shaft","शाफ्ट","scaffold","ମହଲା")) category = "fall";
  else if (has("wire","तार","current","करंट","बिजली","shock","electric","ତାର","বিদ্যুৎ","மின்")) category = "electrical";
  else if (has("trench","खुदाई","मिट्टी","collapse","धंस","ଖୋଳା","ମାଟି","pit")) category = "collapse";
  else if (has("crane","क्रेन","கிரேன்","sling","lift","hook")) category = "lifting";
  else if (has("truck","ट्रक","ଟ୍ରକ୍","vehicle","falling","गिरा","dumper")) category = "struck";
  else if (has("fire","आग","আগুন","ନିଆଁ","தீ")) category = "fire";
  else if (has("helmet","हेलमेट","gloves","boots","ppe")) category = "ppe";
  else if (has("water","पानी","जल","garmi","गर्मी","heat","গরম","dizzy","चक्कर")) category = "heat";
  return { language: "", english: "", summary: catLabel(category), category, severity: CAT[category].sev, action: "Inspect the location and make it safe.", duplicate_of: null, source: "rules" };
}

async function triage({ text, audio, zone, chan, photo, pre }) {
  const open = [...tickets.values()].filter(t => t.status !== "fixed" && t.zone === zone).slice(0, 10)
    .map(t => ({ code: t.code, category: t.category, summary: t.summary, english: t.english }));
  let aiError = "";
  if (ai) {
    const parts = [];
    if (audio && audio.data) parts.push({ inlineData: { mimeType: audio.mimeType || "audio/wav", data: audio.data } });
    const img = photo ? dataUrlPart(photo) : null;
    if (img) parts.push(img);
    const who = chan === "worker" ? "construction worker (by phone)" : "site supervisor (by voice note)";
    const prompt = `You are the triage step of SurakshaVaani, a hazard reporting system for construction sites in India.
A ${who} reported a hazard. It may be in Hindi, Bhojpuri, Odia, Bengali, Tamil, Telugu, Marathi, Hinglish or English.
${audio ? "The report is the attached audio recording. Listen to it carefully." : ""}
${text ? `${audio ? "They also typed" : "Their words (from speech-to-text, may contain errors)"}:\n"""${String(text).slice(0, 1500)}"""` : ""}
${img ? "They also attached a photo. Use it to confirm or sharpen what the hazard is, but base the translation only on the words." : ""}

Zone chosen by the reporter: ${zone}
Open tickets already in this zone (JSON): ${JSON.stringify(open)}

Categories (use the id): ${CATS.map(c => c.id + " = " + c.label).join("; ")}
Severity: "high" if it could kill or seriously injure soon (falls from height, electrocution, collapse, crane or lifting failure, fire); "medium" for injury or health risk; "low" for minor risk.

Reply with only one JSON object:
{"is_hazard": true or false,${audio ? ` "original": "exact transcript of the audio in its own language and script",` : ""} "language": "language name of the report", "english": "faithful one-sentence English translation", "summary": "hazard title in 3 to 7 words", "category": "category id", "severity": "high|medium|low", "action": "one immediate action for the safety engineer, at most 15 words", "duplicate_of": "code of an open ticket above that describes the SAME hazard, or null"${img ? `, "photo_note": "what the photo shows that matters for safety, at most 14 words"` : ""}}`;
    try {
      const r = await gemJSON(prompt, parts);
      if (r && typeof r === "object" && r.english) {
        const category = CAT[r.category] ? r.category : "other";
        const severity = SEVRANK[r.severity] ? r.severity : CAT[category].sev;
        const dup = open.find(o => o.code === r.duplicate_of) ? r.duplicate_of : null;
        return {
          is_hazard: r.is_hazard !== false, original: audio && r.original ? String(r.original).slice(0, 2000) : "",
          language: String(r.language || ""), english: String(r.english), summary: String(r.summary || catLabel(category)).slice(0, 80),
          category, severity, action: String(r.action || ""), duplicate_of: dup,
          photoNote: img && r.photo_note ? String(r.photo_note).slice(0, 140) : "", source: "ai"
        };
      }
      aiError = "Gemini's answer was missing the translation.";
    } catch (e) {
      aiError = e.message || String(e);
      console.error("Triage with Gemini failed:", aiError);
    }
  }
  // Without Gemini: a pre-written reading for the sample notes, otherwise keyword rules.
  const base = pre && pre.text === text && pre.pre ? { ...pre.pre, source: "sample" } : rulesTriage(text);
  const dupT = [...tickets.values()].find(t => t.status !== "fixed" && t.zone === zone && t.category === base.category && Date.now() - tCreated(t) < 12 * H);
  return { is_hazard: true, ...base, original: "", duplicate_of: dupT ? dupT.code : null,
    english: base.english || "(Translation needs Gemini, which is not connected.)", aiError };
}

/* ---------- App ---------- */
loadStore();
const app = express();
app.use(express.json({ limit: "25mb" }));
app.use(express.static(path.join(ROOT, "public")));

app.get("/api/config", (req, res) => res.json({ ai: !!ai, model: ai ? MODEL : null }));

app.get("/api/tickets", (req, res) => {
  if (Number(req.query.since) === rev) return res.json({ rev, same: true });
  res.json({ rev, startedAt: STARTED, tickets: [...tickets.values()] });
});

// File a report: triage it, then join it to a matching open ticket or open a new one.
app.post("/api/reports", async (req, res) => {
  const b = req.body || {};
  const text = String(b.text || "").trim();
  const audio = b.audio && typeof b.audio.data === "string" ? b.audio : null;
  if (!text && !audio) return res.status(400).json({ error: "Say or type what the hazard is first." });
  if (audio && !ai && !text) return res.status(400).json({ error: "Voice notes need Gemini, which is not connected. Type the report instead." });
  const zone = ZONES.includes(b.zone) ? b.zone : ZONES[0];
  const chan = b.chan === "worker" ? "worker" : "supervisor";
  const tri = await triage({ text, audio, zone, chan, photo: b.photo, pre: b.pre });
  const original = tri.original || text;
  const now = Date.now();
  const report = { at: now, channel: chan, reporter: b.anonymous ? "" : String(b.reporter || "").slice(0, 60), anonymous: !!b.anonymous,
    language: tri.language || String(b.langName || ""), original, english: tri.english };
  if (typeof b.photo === "string" && b.photo.startsWith("data:image/") && b.photo.length < 150000) { report.photo = b.photo; if (tri.photoNote) report.photoNote = tri.photoNote; }
  if (typeof b.clip === "string" && b.clip.startsWith("data:audio/") && b.clip.length < 400000) report.clip = b.clip;

  const dup = tri.duplicate_of && [...tickets.values()].find(t => t.code === tri.duplicate_of && t.status !== "fixed");
  if (dup) {
    dup.reports = [...(dup.reports || []), report];
    if (SEVRANK[tri.severity] > SEVRANK[dup.severity]) dup.severity = tri.severity;
    dup.lastReportAt = now;
    saveSoon();
    return res.json({ kind: "merged", ticket: dup, tri });
  }
  const t = { id: newId(), code: nextCode(), createdAt: now, lastReportAt: now, zone, category: tri.category, severity: tri.severity,
    summary: tri.summary, english: tri.english, original, language: report.language, action: tri.action,
    channel: chan, status: "open", aiSource: tri.source, reports: [report], fixedAt: null, fixPhoto: null, fixNote: "" };
  tickets.set(t.id, t);
  saveSoon();
  res.json({ kind: "created", ticket: t, tri });
});

// Close, reopen or annotate a ticket.
const PATCHABLE = ["status", "fixedAt", "fixPhoto", "fixNote", "fixCheck", "callbacks"];
app.patch("/api/tickets/:id", (req, res) => {
  const t = tickets.get(req.params.id);
  if (!t) return res.status(404).json({ error: "That ticket no longer exists." });
  const p = req.body || {};
  if (typeof p.fixPhoto === "string" && p.fixPhoto.length > 200000) return res.status(413).json({ error: "That photo is too large to store. Try another." });
  for (const k of PATCHABLE) if (k in p) t[k] = p[k];
  saveSoon();
  res.json({ ticket: t });
});

// Before closing: Gemini checks the fix photo and writes the callback in each reporter's language.
app.post("/api/tickets/:id/check-fix", async (req, res) => {
  const t = tickets.get(req.params.id);
  if (!t) return res.status(404).json({ error: "That ticket no longer exists." });
  if (!ai) return res.json({ check: null, callbacks: null, ai: false });
  const { note = "", photo = "" } = req.body || {};
  const langs = [...new Set((t.reports || []).map(r => r.language).filter(Boolean))].slice(0, 5);
  if (!langs.length) langs.push("English");
  const after = dataUrlPart(photo);
  const before = (t.reports || []).map(r => dataUrlPart(r.photo)).find(Boolean);
  const parts = after ? (before ? [before, after] : [after]) : [];
  const photos = !after ? "" : before
    ? "Two photos are attached: first the photo of the hazard that a reporter sent, then the engineer's photo of the fix."
    : "One photo is attached: the engineer's photo of the fix.";
  const prompt = `You are the closing step of SurakshaVaani, a construction-site hazard log in India. The safety engineer wants to close ticket ${t.code}.
Hazard: ${t.summary}. ${t.english}
Zone: ${t.zone}. Action that was asked for: ${t.action || "make it safe"}
Engineer's note on what was done: ${String(note || "(none)").slice(0, 300)}
${photos}
${after ? `
1. Decide whether the fix photo shows that this hazard has been made safe. verdict "fixed" if it clearly does; "unclear" if the photo is too dark, blurred or far away to tell; "not_fixed" if it shows the hazard still there, or shows something unrelated to this hazard. reason: one plain sentence for the engineer, at most 25 words, saying what you can see.
2.` : "1."} Write a short spoken callback message for the people who reported it, in each of these languages: ${langs.join(", ")}. Use each language's own script (Hinglish in Latin script). Say the ticket code ${t.code}, what was fixed and where, and thank them for speaking up. At most 30 words each, warm and plain, as a phone line would say it.

Reply with only one JSON object: {${after ? `"verdict": "fixed|unclear|not_fixed", "reason": "...", ` : ""}"callbacks": {"<language name exactly as listed>": "message"}}`;
  try {
    const r = await gemJSON(prompt, parts);
    const got = r && typeof r.callbacks === "object" && r.callbacks ? r.callbacks : {};
    const callbacks = {};
    for (const l of langs) {
      const k = Object.keys(got).find(x => x.toLowerCase() === l.toLowerCase());
      if (k && typeof got[k] === "string" && got[k].trim()) callbacks[l] = got[k].trim().slice(0, 400);
    }
    const check = after && ["fixed", "unclear", "not_fixed"].includes(r.verdict) ? { verdict: r.verdict, reason: String(r.reason || "").slice(0, 240), at: Date.now() } : null;
    res.json({ check, callbacks: Object.keys(callbacks).length ? callbacks : null, ai: true });
  } catch (e) {
    console.error("Fix check with Gemini failed:", e.message || e);
    res.status(502).json({ error: "Couldn't reach Gemini, so the ticket closed without the photo check." });
  }
});

// Morning toolbox talk, streamed as Gemini writes it.
app.post("/api/talk", async (req, res) => {
  if (!ai) return res.status(503).json({ error: "The toolbox talk needs Gemini, which is not connected." });
  const lang = String((req.body || {}).lang || "Hindi").slice(0, 30);
  const now = Number((req.body || {}).now) || Date.now();
  const all = [...tickets.values()];
  const open = all.filter(t => t.status !== "fixed").sort((a, b) => SEVRANK[b.severity] - SEVRANK[a.severity]).slice(0, 8)
    .map(t => ({ hazard: t.summary, zone: t.zone, severity: t.severity, hours_open: Math.round((now - tCreated(t)) / H), reports: (t.reports || []).length, action: t.action }));
  const grid = {};
  for (const t of all) { const k = t.zone + " | " + catLabel(t.category); grid[k] = (grid[k] || 0) + 1; }
  const repeats = Object.entries(grid).filter(([, n]) => n >= 2).map(([k, n]) => ({ where_and_type: k, tickets: n }));
  const fixed = all.filter(t => t.status === "fixed").sort((a, b) => (b.fixedAt || 0) - (a.fixedAt || 0)).slice(0, 4)
    .map(t => ({ hazard: t.summary, zone: t.zone, fix: t.fixNote || "" }));
  const prompt = `You write the morning toolbox talk for a construction site in India. The safety officer reads it out to the workers at the 8 am briefing.
Write it in ${lang}${lang === "English" ? "" : ", in that language's own script"}, in simple spoken words that a worker with little schooling understands. About 150 to 200 words, under two minutes aloud. Plain text only: no headings, no bullet symbols, no markdown, short paragraphs.
Cover, in this order: greet the crew; the one or two most dangerous open hazards, exactly where they are and what to do or avoid today; one hazard that keeps coming back and the habit that prevents it; thank the people who reported hazards (no names) and give one example of something that was fixed; end by reminding them anyone can report a hazard by a missed call to the site line or a voice note to their supervisor, and that workers can stay anonymous.
Use only facts from the log below. Do not invent numbers or places.

OPEN HAZARDS: ${JSON.stringify(open)}
HAZARDS THAT KEEP COMING BACK: ${JSON.stringify(repeats)}
RECENTLY FIXED: ${JSON.stringify(fixed)}`;
  try {
    const stream = await ai.models.generateContentStream({ model: MODEL, contents: [{ role: "user", parts: [{ text: prompt }] }], config: { temperature: 0.6 } });
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("Cache-Control", "no-store");
    for await (const chunk of stream) { if (chunk.text) res.write(chunk.text); }
    res.end();
  } catch (e) {
    console.error("Toolbox talk with Gemini failed:", e.message || e);
    if (!res.headersSent) res.status(502).json({ error: "Couldn't write the talk. Try again." });
    else res.end();
  }
});

// Remove tickets filed during a demo; the example tickets stay.
app.delete("/api/demo-reports", (req, res) => {
  let n = 0;
  for (const [id, t] of tickets) if (!t.seeded) { tickets.delete(id); n++; }
  if (n) saveSoon();
  res.json({ deleted: n });
});

app.listen(PORT, () => {
  console.log(`SurakshaVaani is running at http://localhost:${PORT}`);
  console.log(ai ? `Gemini connected (model ${MODEL}).` : "No GEMINI_API_KEY set: running with keyword rules instead of Gemini.");
});
